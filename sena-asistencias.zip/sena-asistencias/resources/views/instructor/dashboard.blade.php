<h1>Panel Instructor</h1>
<p>Aquí podrás crear clases y generar códigos QR.</p>
