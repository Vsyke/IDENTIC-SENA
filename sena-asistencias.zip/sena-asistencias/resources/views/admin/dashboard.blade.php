<h1>Panel Administrador</h1>
<p>Bienvenido, aquí administrarás usuarios, clases y dispositivos.</p>
