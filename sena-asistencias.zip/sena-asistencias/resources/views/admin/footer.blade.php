<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">Identic-Sena | V1.0</div>
    <strong>
      Copyright &copy; {{ date('Y') }}&nbsp;
      <a href="https://www.sena.edu.co/" target="_blank" class="text-decoration-none">Servicio Nacional de Aprendizaje (SENA)</a>.
    </strong>
    Todos los derechos reservados.
    </footer>