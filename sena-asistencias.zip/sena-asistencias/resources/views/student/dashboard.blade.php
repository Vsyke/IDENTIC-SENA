<h1>Panel Estudiante</h1>
<p>Aquí verás tus asistencias y dispositivos registrados.</p>
