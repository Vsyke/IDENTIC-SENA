<h1>Panel Estudiante</h1>
<p>Aquí verás tus asistencias y dispositivos registrados.</p>
<?php /**PATH C:\Users\Arnold Gil\Downloads\SENA\PHP\Proyecto IdenticSena\sena-asistencias\resources\views/student/dashboard.blade.php ENDPATH**/ ?>